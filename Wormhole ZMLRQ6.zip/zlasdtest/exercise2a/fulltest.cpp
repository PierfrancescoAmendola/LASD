
#include <iostream>

/* ************************************************************************** */

void testFullExercise2A(uint &, uint &) {
}
