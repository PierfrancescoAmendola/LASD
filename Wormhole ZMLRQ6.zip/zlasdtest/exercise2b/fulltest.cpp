
#include <iostream>

/* ************************************************************************** */

void testFullExercise2B(uint &, uint &) {
}
